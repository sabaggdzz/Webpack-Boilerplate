import $ from 'jquery';



$(document).ready(function (){
   $('h1').css('fontSize','150px');
   $('h2').css('fontSize', '150px');
})


