
import 'bootstrap/js/dist/modal';